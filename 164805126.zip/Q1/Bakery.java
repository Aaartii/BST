import java.util.*;



public class Bakery {
    static int solve(ArrayList<Integer> cakes){
        // TO be completed by students
        SkipList s = new SkipList();
        s.insert(cakes.get(0));
        int answer = 0;
        for(int i =1; i<=cakes.size()-1; i++ ){
            if (s.upperBound(cakes.get(i)) != Integer.MAX_VALUE && s.head.next.get(0) != s.tail ){ 
                s.delete(s.upperBound(cakes.get(i)));
                s.insert(cakes.get(i));
                
                
            }
            else{
               s.insert(cakes.get(i));
            }
        }
        answer=s.sizeOfSkipList();
        
        return answer;
}

    
    
}
