import java.util.ArrayList;
import java.util.Collections;


public class SkipList {

        public SkipListNode head;
        public SkipListNode tail;
        public int height;
        public Randomizer randomizer;
        private final int NEG_INF = Integer.MIN_VALUE;
        private final int POS_INF = Integer.MAX_VALUE;

        SkipList(){
            /*
            * DO NOT EDIT THIS FUNCTION
            */
            this.head = new SkipListNode(NEG_INF,1);
            this.tail = new SkipListNode(POS_INF,1);
            this.head.next.add(0,this.tail);
            this.tail.next.add(0,null);
            this.height = 1;
            this.randomizer = new Randomizer();
        }
        public int sizeOfSkipList(){
            
            SkipListNode curr= this.head;
            int  size=0;
            while(curr.next.get(0)!=null){
                size++;
                curr=curr.next.get(0);

            } 
            size--;
           
            return size;
        }

        public boolean delete(int num){
            
            SkipListNode arr = head;
            SkipListNode[] update = new SkipListNode[height+1];
            boolean om = false;  
            for (int i = height-1; i >= 0; i--) {
                while (arr.next.get(i) != null && arr.next.get(i).value < num)
                    arr = arr.next.get(i);
                update[i] = arr;
            }
            arr=arr.next.get(0);
  
            if(arr!=null && arr.value == num){
                for (int i = 0; i < height; i++) {
                    if (update[i].next.get(i) != arr)
                        break;
                        update[i].next.set(i, arr.next.get(i));
                        om = true;
                    while(height>=0 && head.next.get(i)==null){
                            height--;  
                }     
            }
            }
            return om;
        }

        public boolean search(int num){
             
            // create a new array
            SkipListNode cur = this.head;
            for (int i = this.height - 1 ; i >= 0; i--) {
                while (cur.next.get(i)!= null && cur.next.get(i).value < num ) {
                    cur = cur.next.get(i);
                    
                }
            }
            //pointing to the next node
            cur = cur.next.get(0);
            
            return (cur!=null && cur.value == num);   
        }

        public Integer upperBound(int num){ 
             
            // TO be completed by students 
              
            SkipListNode cur = head;
            for (int i = this.height - 1; i >= 0; i--) {
                while (cur.next.get(i).value <= num) {
                    cur = cur.next.get(i);
                }
            }
            cur = cur.next.get(0);
            if (cur != null && cur.value >= num) {
                return cur.value;
            } else {
                return POS_INF;
            }        
        }
        

        public void insert(int num) {
             //creating variable for height
            int h = 1;
            while( h<=this.height && randomizer.binaryRandomGen()==true){
            h++;
            if (h > this.height) {
                this.head.height=h;
                this.tail.height=h;
                this.head.next.add(this.tail);
                this.tail.next.add(null);
                this.height = h;
                break;
            }
           }
           //creating new skiplist node
           SkipListNode arom[]=new SkipListNode[this.height+1];
           //pointing null
           java.util.Arrays.fill(arom, null);
           SkipListNode curr = this.head;
           //
            for (int i = this.height - 1; i >= 0; i--) {
                while (curr.next.get(i)!=null && curr.next.get(i).value < num ) {
                    curr = curr.next.get(i);
                }
                arom[i]= curr;
            }
            curr = curr.next.get(0);

            SkipListNode newNode = new SkipListNode(num, h);
            
            for (int i = 0; i < h; i++) {
                newNode.next.add(i, arom[i].next.get(i));
                arom[i].next.set(i, newNode);
            }
        }
        
        
        public void print(){
            /*
            * DO NOT EDIT THIS FUNCTION
            */
            for(int i = this.height ; i>=1; --i){
                SkipListNode it = this.head;
                while(it!=null){
                    if(it.height >= i){
                        System.out.print(it.value + "\t");
                    }
                    else{
                        System.out.print("\t");
                    }
                    it = it.next.get(0);
                }
                System.out.println("null");
            }
        }
        
}